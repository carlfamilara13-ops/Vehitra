# Vehicle availability notifications: backend work required

The mobile app can only deliver local reminders today. The existing Supabase schema and Web admin workflow support model requests and publishing catalog versions, but the repository has no push-token registration, push delivery function, or notification delivery ledger. The mobile app also has no model-request feature wired to this backend. Vehicle-availability push delivery is therefore not implemented here.

A backend implementation should:

1. Add authenticated mobile request creation/listing and allow a user to request a specific `vehicle_models.id` (or canonical model slug). Match availability by that exact identifier; do not notify by brand or fuzzy model text.
2. Add per-user device push-token registration with platform, installation identifier, updated timestamp, and token revocation/rotation handling. Enforce row-level access so users can only manage their own tokens.
3. Emit an availability event only when a model transitions from unpublished/unavailable to published and has a usable current catalog version. Do not emit for every component row or for routine edits to an already available model.
4. Resolve recipients server-side from open requests for the exact model, respecting account status and notification preference. Deduplicate with a unique delivery key such as `(user_id, model_id, published_version)` so retries and duplicate events cannot send duplicates.
5. Deliver through a trusted server-side worker/Edge Function using the configured Expo Push Service or native FCM/APNs credentials. Validate provider receipts, retire invalid tokens, and retain delivery status/error for retries and support. Never place provider secrets in the mobile app or Vehitra Web client.
6. Include a stable model identifier and published version in payload data. The app should route taps to that model, then mark the matching request as notified/fulfilled without changing unrelated requests.
7. Add integration tests for exact-model targeting, multiple requested models, duplicate publish events, multiple devices, revoked tokens, user opt-out, retry behavior, and row-level security.

This work depends on choosing and configuring a push provider, defining the request lifecycle, and deploying the server-side delivery path. Local movement, stationary, maintenance, and document reminders remain offline-capable and do not depend on this backend work.
